from flask import Flask, request, jsonify
from flask_restful import Api, Resource
from marshmallow import Schema, fields, ValidationError

# Create Flask app and API
app = Flask(__name__)
api = Api(app)

# Data store (In-memory for this example, can be replaced with a database)
data_store = []

# Define Marshmallow schema for data serialization and validation
class CategorySchema(Schema):
    Category = fields.Str(required=True)
    Subcategory = fields.Str(required=True)
    URL = fields.Str(required=True)

# Resource for handling POST requests for categories
class CategoryAPI(Resource):
    def post(self):
        try:
            # Get the JSON data from the request
            request_data = request.get_json()

            # Initialize the schema for validation and serialization
            category_schema = CategorySchema(many=True)
            
            # Validate and deserialize the input data
            categories = category_schema.load(request_data)

            # Append the valid data to the in-memory store
            data_store.extend(categories)

            # Serialize the data from the store
            result = category_schema.dump(data_store)

            # Return the serialized data and the count of saved items
            return jsonify({
                'data': result,
                'count': len(data_store)
            })

        except ValidationError as err:
            return jsonify({"error": err.messages}), 400
        except Exception as e:
            return jsonify({"error": str(e)}), 500

# Add the CategoryAPI resource to the API
api.add_resource(CategoryAPI, '/categories')

# Run the Flask application
if __name__ == '__main__':
    app.run(debug=True)
